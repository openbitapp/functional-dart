import 'package:gl_functional/gl_functional.dart';
import 'package:gl_functional/src/option.dart';
import 'package:gl_functional/src/validation.dart';
import 'package:gl_functional/src/function_extension.dart';
import 'package:test/test.dart';

class Animal {
  final String name;
  Animal(this.name);

  @override
  String toString() => name;
}

class FriendOfAnimals {
  final String name;
  final animals = <Animal>[];

  FriendOfAnimals(this.name);

  void addAnimal(String name) {
    animals.add(Animal(name));
  }
}

class Person {
  final Option<int> eta;
  Person({int eta}) : eta = eta != null ? Some(eta) : None<int>();
}

class FakeError extends Error {}

void main() {
  group('A group of tests', () {
    Option<int> option;
    Iterable<Person> population;

    setUp(() {
      option = Option.some(3);
      population = [Person(eta: 40), Person(), Person(eta: 10)];
    });

    test('First Test', () {
      expect(option.isSome, isTrue);

      final optionStr = option.map((t) => t.toString());
      optionStr.fold(() => fail('Value expected'), (some) => print(some));

      final none = Option<int>.none();
      final anotherNone = none.map((t) => t.toString());
      anotherNone.fold(() => null, (some) => fail('None expected'));

      anotherNone.foreach(print);
      optionStr.foreach(print);

      final l = <FriendOfAnimals>[];
      final luca = FriendOfAnimals('Luca');
      final giorgio = FriendOfAnimals('Giorgio');

      luca.addAnimal('Cerbero');
      luca.addAnimal('Fuffy');

      giorgio.addAnimal('Sissy');
      giorgio.addAnimal('Piccolo');
      l.addAll([luca, giorgio]);

      final nested = l.map((e) => e.animals);
      print(nested);

      final flat = l.bind((e) => e.animals);
      print(flat);

      option
          .where((t) => t > 0)
          .fold(() => fail('Value Expeted'), (some) => print(some));

      anotherNone
          .where((t) => true)
          .fold(() => null, (some) => fail('None expected'));

      expect(anotherNone.asIterable().length, 0);
      expect(option.asIterable().length, 1);

      final listOptionEta = population.map((p) => p.eta);
      expect(listOptionEta.length, 3);

      final listEta = population.flatMap((p) => p.eta);
      expect(listEta.length, 2);

      final optionalAges = Some(listEta);
      final adjustedAges = optionalAges.flatMap((t) => t.map((e) => e * 2));

      final validation = Invalid<int>([FakeError()]);

      String test({int i, String s}) => '$s $i';

      final testPartial = ({int i}) => ({String s}) => test(i: i, s: s);
      final tp2 = testPartial(i: 10);
      print(tp2(s: 'ciao'));

      final testPartialSwapped = ({String s}) => ({int i}) => test(i: i, s: s);
      final tpswapped = testPartialSwapped(s: 'ciao swapped');
      print(tpswapped(i: 20));

      final applied = ({String s}) => test(i: 10, s: s);
      print(applied(s: 'Ciao applied'));
      // final testSwapped = test.swapArgs();
      // final testApplied = test.apply(10);
      // test.curry()(10)('ciao');
    });
  });
}
