class Error {
  final String message;
  Error(this.message);
}
