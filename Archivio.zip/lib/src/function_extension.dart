extension FunctionExtensions<T1, T2, R> on R Function(T1, T2) {
  R Function(T2, T1) swapArgs() => (T2 t2, T1 t1) => this(t1, t2);
  R Function(T2) apply(T1 t1) => (T2 t2) => this(t1, t2);
  R Function(T2) Function(T1) curry() => (T1 t1) => (T2 t2) => this(t1, t2);
}

extension FunctionExtensions2<T1, T2, T3, R> on R Function(T1, T2, T3) {
  R Function(T2, T3) apply(T1 t1) => (T2 t2, T3 t3) => this(t1, t2, t3);
}
