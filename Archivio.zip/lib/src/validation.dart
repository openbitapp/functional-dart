Validation<T> Valid<T>(T value) => Validation.valid(value);
Validation<T> Invalid<T>(Iterable<Error> errors) => Validation.invalid(errors);

class Validation<T> {
  final Iterable<Error> _errors;
  final T _value;
  bool get isValid => _errors.isNotEmpty;

  Validation.valid(T value)
      : _value = value,
        _errors = <Error>[];
  Validation.invalid(Iterable<Error> errors)
      : _errors = errors,
        _value = null;

  TR fold<TR>(
          TR Function(Iterable<Error> err) invalid, TR Function(T val) valid) =>
      isValid ? valid(_value) : invalid(_errors);

  Iterable<T> asIterable() sync* {
    if (isValid) {
      yield _value;
    }
  }

  Validation<R> map<R>(R Function(T val) f) =>
      fold((err) => Invalid(err), (v) => Valid(f(v)));

  Validation<void> forEach(void Function(T val) action) => map(action);

  Validation<T> andThen(void Function(T t) action) {
    forEach(action);
    return this;
  }

  Validation<R> bind<R>(Validation<R> Function(T val) f) =>
      fold((err) => Invalid(err), (v) => f(v));
}
