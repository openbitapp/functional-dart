import 'package:gl_functional/src/iterator_extensions.dart';

Option<T> None<T>() => Option.none();
Option<T> Some<T>(T value) => Option.some(value);

class Option<T> {
  final T _value;
  final bool isSome;

  const Option.some(this._value) : isSome = true;
  const Option.none()
      : _value = null,
        isSome = false;

  R fold<R>(R Function() none, R Function(T some) some) {
    return isSome ? some(_value) : none();
  }

  Option<R> map<R>(R Function(T t) f) =>
      fold(() => Option.none(), (some) => Option.some(f(some)));

  Option<void> foreach(void Function(T t) f) => map((t) => f(t));

  Option<R> bind<R>(Option<R> Function(T t) f) =>
      fold(() => Option.none(), (some) => f(some));

  Option<T> where(bool Function(T t) f) => fold(() => Option.none(),
      (some) => f(some) ? Option.some(some) : Option.none());

  Iterable<T> asIterable() sync* {
    if (isSome) {
      yield _value;
    }
  }

  Iterable<R> flatMap<R>(Iterable<R> Function(T t) f) {
    return asIterable().bind(f);
  }
}
